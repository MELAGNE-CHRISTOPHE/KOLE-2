import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext';

// Composants de chargement et d'erreur
import LoadingScreen from './components/common/LoadingScreen';
import ErrorBoundary from './components/common/ErrorBoundary';

// Pages principales
import SplashScreen from './pages/SplashScreen';
import LoginPage from './pages/LoginPage';
import AdminLoginPage from './pages/AdminLoginPage';
import AdminLoginDirect from './pages/AdminLoginDirect';
import NotFoundPage from './pages/NotFoundPage';
import UnauthorizedPage from './pages/UnauthorizedPage';
import { Suspense, lazy } from 'react';

// Pages avec chargement différé (lazy loading)
const ClientMainMapPage = lazy(() => import('./pages/client/ClientMainMapPage'));
const ClientBookingPage = lazy(() => import('./pages/client/ClientBookingPage'));
const ClientSearchingDriverPage = lazy(() => import('./pages/client/ClientSearchingDriverPage'));
const ClientTrackRidePage = lazy(() => import('./pages/client/ClientTrackRidePage'));
const ClientRateRidePage = lazy(() => import('./pages/client/ClientRateRidePage'));
const ClientRideCompletedPage = lazy(() => import('./pages/client/ClientRideCompletedPage'));

const DriverDashboard = lazy(() => import('./pages/driver/DriverDashboard'));
const DriverMainMapPage = lazy(() => import('./pages/driver/DriverMainMapPage'));
const DriverNavigateToClientPage = lazy(() => import('./pages/driver/DriverNavigateToClientPage'));
const DriverNavigateToDestinationPage = lazy(() => import('./pages/driver/DriverNavigateToDestinationPage'));

// Routes administrateur
const AdminRoutes = lazy(() => import('./pages/AdminRoutes'));

// Mode développement pour contourner les vérifications d'authentification
const DEV_MODE = import.meta.env.VITE_DEV_MODE === 'true' || true;

const App: React.FC = () => {
  const { currentUser, userRole, loading, setBypassAuthCheck } = useAuth();
  const location = useLocation();

  // Activer le contournement des vérifications d'authentification en mode développement
  React.useEffect(() => {
    if (DEV_MODE) {
      console.log('[App] Mode développement activé, contournement des vérifications d\'authentification');
      setBypassAuthCheck(true);
    }
  }, [setBypassAuthCheck]);

  // Redirection automatique selon le rôle après connexion
  const getHomeRoute = () => {
    if (DEV_MODE) return '/splash'; // En mode dev, commencer par le splash screen
    
    if (!currentUser) return '/login';
    
    switch (userRole) {
      case 'client':
        return '/client';
      case 'driver':
        return '/driver';
      case 'admin':
        return '/admin';
      default:
        return '/login';
    }
  };

  // Composant de route simple pour le mode développement
  const SimpleRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (DEV_MODE) {
      console.log('[SimpleRoute] Mode développement - Accès direct accordé');
      return <>{children}</>;
    }
    
    if (loading) {
      return <LoadingScreen />;
    }
    
    return <>{children}</>;
  };

  if (loading && !DEV_MODE) {
    return <LoadingScreen />;
  }

  return (
    <ErrorBoundary>
      <div className="App">
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            {/* Route racine - Splash Screen selon les maquettes */}
            <Route path="/" element={<Navigate to="/splash" replace />} />
            
            {/* Splash Screen */}
            <Route path="/splash" element={<SplashScreen />} />
            
            {/* Pages d'authentification selon les maquettes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/admin-login" element={<AdminLoginPage />} />
            <Route path="/admin-login-direct" element={<AdminLoginDirect />} />
            
            {/* Routes Client avec design conforme aux maquettes */}
            <Route path="/client" element={
              <SimpleRoute>
                <ClientMainMapPage />
              </SimpleRoute>
            } />
            <Route path="/client/booking" element={
              <SimpleRoute>
                <ClientBookingPage />
              </SimpleRoute>
            } />
            <Route path="/client/searching" element={
              <SimpleRoute>
                <ClientSearchingDriverPage />
              </SimpleRoute>
            } />
            <Route path="/client/track" element={
              <SimpleRoute>
                <ClientTrackRidePage />
              </SimpleRoute>
            } />
            <Route path="/client/rate" element={
              <SimpleRoute>
                <ClientRateRidePage />
              </SimpleRoute>
            } />
            <Route path="/client/completed" element={
              <SimpleRoute>
                <ClientRideCompletedPage />
              </SimpleRoute>
            } />
            
            {/* Routes Chauffeur avec design conforme aux maquettes */}
            <Route path="/driver" element={
              <SimpleRoute>
                <DriverDashboard />
              </SimpleRoute>
            } />
            <Route path="/driver/map" element={
              <SimpleRoute>
                <DriverMainMapPage />
              </SimpleRoute>
            } />
            <Route path="/driver/navigate-to-client" element={
              <SimpleRoute>
                <DriverNavigateToClientPage />
              </SimpleRoute>
            } />
            <Route path="/driver/navigate-to-destination" element={
              <SimpleRoute>
                <DriverNavigateToDestinationPage />
              </SimpleRoute>
            } />
            
            {/* Routes Administrateur avec design conforme aux maquettes */}
            <Route path="/admin/*" element={
              <SimpleRoute>
                <AdminRoutes />
              </SimpleRoute>
            } />
            
            {/* Pages d'erreur */}
            <Route path="/unauthorized" element={<UnauthorizedPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Suspense>
      </div>
    </ErrorBoundary>
  );
};

export default App;

