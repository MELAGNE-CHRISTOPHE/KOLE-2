import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard,
  Users,
  Car,
  DollarSign,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  Search
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const menuItems = [
    {
      icon: LayoutDashboard,
      label: 'Tableau de bord',
      path: '/admin',
      active: location.pathname === '/admin'
    },
    {
      icon: Users,
      label: 'Gestion des utilisateurs',
      path: '/admin/users',
      active: location.pathname === '/admin/users'
    },
    {
      icon: Car,
      label: 'Gestion des chauffeurs',
      path: '/admin/drivers',
      active: location.pathname === '/admin/drivers'
    },
    {
      icon: DollarSign,
      label: 'Transactions',
      path: '/admin/transactions',
      active: location.pathname === '/admin/transactions'
    },
    {
      icon: BarChart3,
      label: 'Statistiques',
      path: '/admin/statistics',
      active: location.pathname === '/admin/statistics'
    },
    {
      icon: Settings,
      label: 'Paramètres',
      path: '/admin/settings',
      active: location.pathname === '/admin/settings'
    }
  ];

  const handleLogout = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-kole-cream-light">
      {/* Sidebar verticale selon les maquettes */}
      <div className={`kole-admin-sidebar ${sidebarOpen ? 'open' : ''}`}>
        {/* Logo et titre */}
        <div className="px-6 mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-kole-blue-primary rounded-full flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-white rounded-full relative">
                <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-white rounded-full"></div>
                <div className="absolute bottom-0.5 right-0.5 w-1 h-1 bg-white rounded-full"></div>
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Kôlê Admin</h1>
              <p className="text-sm text-gray-300">Panneau d'administration</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  setSidebarOpen(false);
                }}
                className={`kole-admin-sidebar-item w-full ${item.active ? 'active' : ''}`}
              >
                <IconComponent className="h-5 w-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Bouton de déconnexion */}
        <div className="px-6 pb-6">
          <button
            onClick={handleLogout}
            className="kole-admin-sidebar-item w-full text-red-300 hover:text-red-200 hover:bg-red-900/20"
          >
            <LogOut className="h-5 w-5" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Contenu principal */}
      <div className="kole-admin-content">
        {/* En-tête mobile */}
        <div className="md:hidden flex items-center justify-between mb-6 bg-white p-4 rounded-lg shadow-sm">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-gray-100"
          >
            {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
          <h1 className="text-lg font-semibold text-kole-text-dark">Kôlê Admin</h1>
          <button className="p-2 rounded-lg hover:bg-gray-100">
            <Bell className="h-6 w-6 text-kole-text-secondary" />
          </button>
        </div>

        {/* Contenu de la page */}
        {children}
      </div>

      {/* Overlay mobile */}
      {sidebarOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default AdminLayout;

