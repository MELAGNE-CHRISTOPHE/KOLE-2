import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  UserCog, 
  MapPin, 
  Wallet, 
  BarChart2, 
  Settings,
  UserCheck
} from 'lucide-react';

interface SidebarItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ to, icon, label, isActive }) => {
  return (
    <Link
      to={to}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        isActive 
          ? 'bg-blue-700 text-white' 
          : 'text-white hover:bg-blue-700/50'
      }`}
    >
      <div className="w-5 h-5">{icon}</div>
      <span>{label}</span>
    </Link>
  );
};

const Sidebar: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const menuItems = [
    {
      to: '/admin',
      icon: <LayoutDashboard size={20} />,
      label: 'Tableau de bord',
    },
    {
      to: '/admin/chauffeurs',
      icon: <UserCog size={20} />,
      label: 'Gestion Chauffeurs',
    },
    {
      to: '/admin/clients',
      icon: <Users size={20} />,
      label: 'Gestion Clients',
    },
    {
      to: '/admin/roles',
      icon: <UserCheck size={20} />,
      label: 'Gestion des Rôles',
    },
    {
      to: '/admin/trajets',
      icon: <MapPin size={20} />,
      label: 'Suivi Trajets',
    },
    {
      to: '/admin/finance',
      icon: <Wallet size={20} />,
      label: 'Finance',
    },
    {
      to: '/admin/statistiques',
      icon: <BarChart2 size={20} />,
      label: 'Statistiques',
    },
    {
      to: '/admin/parametres',
      icon: <Settings size={20} />,
      label: 'Paramètres',
    },
  ];

  return (
    <div className="h-screen w-64 bg-blue-600 text-white flex flex-col">
      <div className="p-4 flex justify-center items-center border-b border-blue-500">
        <h1 className="text-2xl font-bold">Kôlê Admin</h1>
      </div>
      <div className="flex-1 py-4 flex flex-col gap-1">
        {menuItems.map((item) => (
          <SidebarItem
            key={item.to}
            to={item.to}
            icon={item.icon}
            label={item.label}
            isActive={
              item.to === '/admin'
                ? currentPath === '/admin'
                : currentPath.startsWith(item.to)
            }
          />
        ))}
      </div>
      <div className="p-4 border-t border-blue-500">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-300 flex items-center justify-center">
            A
          </div>
          <div>
            <p className="text-sm font-medium">Admin</p>
            <button className="text-xs text-blue-200 hover:text-white">
              Déconnexion
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
