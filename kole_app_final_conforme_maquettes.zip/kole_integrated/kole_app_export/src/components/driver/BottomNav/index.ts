export { default as BottomNav } from "./BottomNav";

