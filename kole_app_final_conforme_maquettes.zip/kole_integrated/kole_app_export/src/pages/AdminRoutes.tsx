import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminLayout from '../components/admin/AdminLayout';
import AdminDashboard from './admin/AdminDashboard';
import DriversManagement from './admin/DriversManagement';
import ClientsManagement from './admin/ClientsManagement';
import RidesTracking from './admin/RidesTracking';
import FinanceManagement from './admin/FinanceManagement';
import UserRolesManagement from './admin/UserRolesManagement';
import StatisticsPage from './admin/StatisticsPage';
import SettingsPage from './admin/SettingsPage';

const AdminRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
      <Route path="/dashboard" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
      <Route path="/chauffeurs" element={<AdminLayout><DriversManagement /></AdminLayout>} />
      <Route path="/clients" element={<AdminLayout><ClientsManagement /></AdminLayout>} />
      <Route path="/trajets" element={<AdminLayout><RidesTracking /></AdminLayout>} />
      <Route path="/finance" element={<AdminLayout><FinanceManagement /></AdminLayout>} />
      <Route path="/roles" element={<AdminLayout><UserRolesManagement /></AdminLayout>} />
      <Route path="/statistiques" element={<AdminLayout><StatisticsPage /></AdminLayout>} />
      <Route path="/parametres" element={<AdminLayout><SettingsPage /></AdminLayout>} />
    </Routes>
  );
};

export default AdminRoutes;

