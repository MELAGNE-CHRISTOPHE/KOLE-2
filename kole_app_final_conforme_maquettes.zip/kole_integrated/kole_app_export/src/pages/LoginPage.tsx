import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Eye, 
  EyeOff, 
  Mail, 
  Lock, 
  User,
  Car
} from 'lucide-react';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Logique de connexion simplifiée pour la démo
    navigate('/client');
  };

  const handleDriverLogin = () => {
    navigate('/driver');
  };

  const handleSignUp = () => {
    navigate('/signup');
  };

  return (
    <div className="min-h-screen bg-kole-cream-light african-pattern-bg flex items-center justify-center p-4">
      {/* Motifs africains discrets en haut et en bas */}
      <div className="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-kole-ocre/10 to-transparent african-pattern-border"></div>
      <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-kole-ocre/10 to-transparent african-pattern-border"></div>
      
      <div className="w-full max-w-md relative z-10">
        {/* Logo et titre selon les maquettes */}
        <div className="text-center mb-8">
          <div className="mb-4">
            {/* Symbole Kôlê stylisé */}
            <div className="w-16 h-16 mx-auto mb-4 bg-kole-brown-dark rounded-full flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-kole-ocre rounded-full relative">
                <div className="absolute top-1 left-1 w-2 h-2 bg-kole-ocre rounded-full"></div>
                <div className="absolute bottom-1 right-1 w-2 h-2 bg-kole-ocre rounded-full"></div>
              </div>
            </div>
            <h1 className="text-3xl font-bold text-kole-brown-dark mb-2">Kôlê</h1>
          </div>
        </div>

        {/* Carte de connexion selon les maquettes */}
        <div className="kole-card shadow-lg">
          <div className="p-8">
            <h2 className="text-2xl font-bold text-kole-brown-dark mb-6 text-center">Connexion</h2>
            
            <form onSubmit={handleLogin} className="space-y-6">
              {/* Champ Email */}
              <div>
                <label className="block text-sm font-medium text-kole-text-dark mb-2">
                  E-mail ou téléphone
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-kole-text-secondary" />
                  <input
                    type="email"
                    placeholder="E-mail ou téléphone"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 kole-input"
                    required
                  />
                </div>
              </div>

              {/* Champ Mot de passe */}
              <div>
                <label className="block text-sm font-medium text-kole-text-dark mb-2">
                  Mot de passe
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-kole-text-secondary" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Mot de passe"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 kole-input"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-kole-text-secondary hover:text-kole-text-dark"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              {/* Lien mot de passe oublié */}
              <div className="text-right">
                <a 
                  href="/forgot-password" 
                  className="text-sm text-kole-blue-primary hover:underline"
                >
                  Mot de passe oublié ?
                </a>
              </div>

              {/* Bouton de connexion principal */}
              <button 
                type="submit"
                className="w-full kole-btn-primary py-3 text-lg font-semibold flex items-center justify-center"
              >
                <User className="h-5 w-5 mr-2" />
                Se connecter
              </button>

              {/* Séparateur */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-kole-border"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-white text-kole-text-secondary">Ou se connecter avec</span>
                </div>
              </div>

              {/* Options de connexion sociale */}
              <div className="flex justify-center space-x-4 mb-6">
                <button 
                  type="button"
                  className="w-12 h-12 rounded-full bg-white border border-kole-border flex items-center justify-center hover:bg-kole-cream-light transition-colors"
                >
                  <span className="text-lg font-bold text-blue-600">G</span>
                </button>
                <button 
                  type="button"
                  className="w-12 h-12 rounded-full bg-white border border-kole-border flex items-center justify-center hover:bg-kole-cream-light transition-colors"
                >
                  <span className="text-lg font-bold text-blue-800">f</span>
                </button>
              </div>

              {/* Connexion chauffeur */}
              <button 
                type="button"
                onClick={handleDriverLogin}
                className="w-full kole-btn-secondary py-3 text-lg font-semibold flex items-center justify-center"
              >
                <Car className="h-5 w-5 mr-2" />
                Connexion Chauffeur
              </button>
            </form>

            {/* Lien vers inscription */}
            <div className="text-center mt-8">
              <span className="text-kole-text-secondary">Pas encore de compte ? </span>
              <button 
                onClick={handleSignUp}
                className="text-kole-blue-primary hover:underline font-semibold"
              >
                S'inscrire
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;

