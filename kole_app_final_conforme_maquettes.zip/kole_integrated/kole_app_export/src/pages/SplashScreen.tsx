import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const SplashScreen: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirection automatique après 3 secondes
    const timer = setTimeout(() => {
      navigate('/login');
    }, 3000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-100 via-amber-50 to-yellow-100 african-pattern-bg flex items-center justify-center relative overflow-hidden">
      {/* Motifs géométriques africains en arrière-plan */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 border-4 border-kole-ocre transform rotate-45"></div>
        <div className="absolute top-32 right-16 w-16 h-16 bg-kole-brown-dark opacity-20 transform rotate-12"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 border-2 border-kole-brown-dark transform -rotate-12"></div>
        <div className="absolute bottom-32 right-12 w-12 h-12 bg-kole-ocre opacity-30 rounded-full"></div>
        
        {/* Motifs kente simplifiés */}
        <div className="absolute top-1/4 left-1/4 w-32 h-2 bg-gradient-to-r from-kole-ocre to-kole-brown-dark opacity-20"></div>
        <div className="absolute top-1/3 right-1/4 w-24 h-2 bg-gradient-to-r from-kole-brown-dark to-kole-ocre opacity-20"></div>
        <div className="absolute bottom-1/4 left-1/3 w-28 h-2 bg-gradient-to-r from-kole-ocre to-kole-brown-dark opacity-20"></div>
      </div>

      {/* Contenu principal */}
      <div className="text-center z-10">
        {/* Logo Kôlê */}
        <div className="mb-8">
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-white drop-shadow-2xl mb-4">
            Kôlê
          </h1>
          <div className="w-24 h-1 bg-kole-blue-primary mx-auto mb-4"></div>
          <p className="text-xl md:text-2xl text-white font-medium drop-shadow-lg">
            VOTRE TRAJET, NOTRE MISSION
          </p>
        </div>

        {/* Indicateur de chargement */}
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-white border-opacity-30 rounded-full animate-spin">
              <div className="absolute top-0 left-0 w-16 h-16 border-4 border-transparent border-t-kole-blue-primary rounded-full animate-spin"></div>
            </div>
          </div>
          <p className="text-kole-blue-primary text-lg font-semibold animate-pulse">
            Bienvenue
          </p>
        </div>
      </div>

      {/* Éléments décoratifs supplémentaires */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-16 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-kole-blue-primary rounded-full animate-ping"></div>
        <div className="absolute bottom-24 left-1/4 w-1 h-1 bg-kole-ocre rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/3 right-1/5 w-1 h-1 bg-kole-brown-dark rounded-full animate-ping" style={{ animationDelay: '2s' }}></div>
      </div>
    </div>
  );
};

export default SplashScreen;

