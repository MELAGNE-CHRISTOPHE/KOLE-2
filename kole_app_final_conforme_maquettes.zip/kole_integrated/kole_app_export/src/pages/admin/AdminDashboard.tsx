import React from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import { 
  Users, 
  Car, 
  DollarSign, 
  TrendingUp,
  Activity,
  MapPin,
  Clock,
  Star,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  // Données simulées selon les maquettes
  const stats = {
    totalUsers: 1247,
    activeDrivers: 89,
    totalTrips: 3456,
    revenue: 2847500,
    pendingDrivers: 12,
    onlineDrivers: 67
  };

  const recentActivities = [
    { id: 1, type: 'trip', message: 'Nouveau trajet terminé par Kouassi Jean', time: '2 min' },
    { id: 2, type: 'driver', message: 'Nouveau chauffeur inscrit: Diabaté Marie', time: '15 min' },
    { id: 3, type: 'payment', message: 'Paiement de 15,000 FCFA reçu', time: '32 min' },
    { id: 4, type: 'issue', message: 'Signalement résolu pour le trajet #3421', time: '1h' }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* En-tête du tableau de bord */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-kole-text-dark">Tableau de bord</h1>
            <p className="text-kole-text-secondary mt-1">Vue d'ensemble de la plateforme Kôlê</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-kole-text-secondary">Dernière mise à jour</p>
            <p className="text-lg font-semibold text-kole-text-dark">Il y a 2 minutes</p>
          </div>
        </div>

        {/* Widgets KPI selon les maquettes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Total Utilisateurs */}
          <div className="kole-stat-card bg-gradient-to-br from-blue-50 to-blue-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-kole-blue-primary rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-white" />
              </div>
              <TrendingUp className="h-5 w-5 text-kole-blue-primary" />
            </div>
            <div className="kole-stat-value text-kole-blue-primary">{stats.totalUsers.toLocaleString()}</div>
            <div className="kole-stat-label">Utilisateurs inscrits</div>
            <div className="mt-2 text-xs text-green-600 font-medium">+12% ce mois</div>
          </div>

          {/* Chauffeurs Actifs */}
          <div className="kole-stat-card bg-gradient-to-br from-orange-50 to-orange-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-kole-orange rounded-full flex items-center justify-center">
                <Car className="h-6 w-6 text-white" />
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-kole-green-success rounded-full animate-pulse"></div>
                <span className="text-xs text-kole-text-secondary">{stats.onlineDrivers} en ligne</span>
              </div>
            </div>
            <div className="kole-stat-value text-kole-orange">{stats.activeDrivers}</div>
            <div className="kole-stat-label">Chauffeurs actifs</div>
            <div className="mt-2 text-xs text-orange-600 font-medium">{stats.pendingDrivers} en attente</div>
          </div>

          {/* Total Trajets */}
          <div className="kole-stat-card bg-gradient-to-br from-green-50 to-green-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-kole-green-success rounded-full flex items-center justify-center">
                <MapPin className="h-6 w-6 text-white" />
              </div>
              <Activity className="h-5 w-5 text-kole-green-success" />
            </div>
            <div className="kole-stat-value text-kole-green-success">{stats.totalTrips.toLocaleString()}</div>
            <div className="kole-stat-label">Trajets effectués</div>
            <div className="mt-2 text-xs text-green-600 font-medium">+8% cette semaine</div>
          </div>

          {/* Revenus */}
          <div className="kole-stat-card bg-gradient-to-br from-purple-50 to-purple-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
              <TrendingUp className="h-5 w-5 text-purple-600" />
            </div>
            <div className="kole-stat-value text-purple-600">{(stats.revenue / 1000000).toFixed(1)}M</div>
            <div className="kole-stat-label">FCFA de revenus</div>
            <div className="mt-2 text-xs text-purple-600 font-medium">+15% ce mois</div>
          </div>
        </div>

        {/* Graphiques et tableaux selon les maquettes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Activités récentes */}
          <div className="kole-card p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-kole-text-dark">Activités récentes</h3>
              <button className="text-kole-blue-primary hover:underline text-sm font-medium">
                Voir tout
              </button>
            </div>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-kole-cream-light transition-colors">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    activity.type === 'trip' ? 'bg-blue-100' :
                    activity.type === 'driver' ? 'bg-orange-100' :
                    activity.type === 'payment' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {activity.type === 'trip' && <MapPin className="h-4 w-4 text-blue-600" />}
                    {activity.type === 'driver' && <Car className="h-4 w-4 text-orange-600" />}
                    {activity.type === 'payment' && <DollarSign className="h-4 w-4 text-green-600" />}
                    {activity.type === 'issue' && <AlertTriangle className="h-4 w-4 text-red-600" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-kole-text-dark">{activity.message}</p>
                    <p className="text-xs text-kole-text-secondary mt-1">Il y a {activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Statut des chauffeurs */}
          <div className="kole-card p-6">
            <h3 className="text-xl font-semibold text-kole-text-dark mb-6">Statut des chauffeurs</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-kole-green-success" />
                  <span className="font-medium text-kole-text-dark">En ligne</span>
                </div>
                <span className="text-2xl font-bold text-kole-green-success">{stats.onlineDrivers}</span>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-gray-500" />
                  <span className="font-medium text-kole-text-dark">Hors ligne</span>
                </div>
                <span className="text-2xl font-bold text-gray-500">{stats.activeDrivers - stats.onlineDrivers}</span>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="h-5 w-5 text-kole-orange" />
                  <span className="font-medium text-kole-text-dark">En attente de validation</span>
                </div>
                <span className="text-2xl font-bold text-kole-orange">{stats.pendingDrivers}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions rapides */}
        <div className="kole-card p-6">
          <h3 className="text-xl font-semibold text-kole-text-dark mb-6">Actions rapides</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="kole-btn-primary p-4 text-left">
              <Users className="h-6 w-6 mb-2" />
              <div className="font-semibold">Gérer les utilisateurs</div>
              <div className="text-sm opacity-90">Voir et modérer les comptes</div>
            </button>
            
            <button className="kole-btn-secondary p-4 text-left">
              <Car className="h-6 w-6 mb-2" />
              <div className="font-semibold">Valider les chauffeurs</div>
              <div className="text-sm opacity-90">{stats.pendingDrivers} en attente</div>
            </button>
            
            <button className="kole-btn-outline p-4 text-left">
              <BarChart3 className="h-6 w-6 mb-2" />
              <div className="font-semibold">Voir les statistiques</div>
              <div className="text-sm opacity-90">Rapports détaillés</div>
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;

