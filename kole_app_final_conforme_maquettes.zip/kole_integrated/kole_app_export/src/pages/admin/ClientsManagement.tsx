import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../../components/ui/table';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { Pencil, Eye, Ban, Trash2 } from 'lucide-react';

// Données fictives pour les clients
const clientsData = [
  { 
    id: 'CL001', 
    name: 'Aminata Touré', 
    phone: '+225 07 11 22 33', 
    email: 'aminata.t@example.com',
    status: 'active',
    registrationDate: '10/05/2025',
    rides: 15,
    balance: 5000
  },
  { 
    id: 'CL002', 
    name: 'Ibrahim Koné', 
    phone: '+225 05 44 55 66', 
    email: 'ibrahim.k@example.com',
    status: 'active',
    registrationDate: '12/05/2025',
    rides: 8,
    balance: 2500
  },
  { 
    id: 'CL003', 
    name: 'Sophie Mensah', 
    phone: '+225 01 77 88 99', 
    email: 'sophie.m@example.com',
    status: 'blocked',
    registrationDate: '05/05/2025',
    rides: 3,
    balance: 0
  },
  { 
    id: 'CL004', 
    name: 'Yao Kouassi', 
    phone: '+225 07 00 11 22', 
    email: 'yao.k@example.com',
    status: 'inactive',
    registrationDate: '15/04/2025',
    rides: 12,
    balance: 3200
  },
  { 
    id: 'CL005', 
    name: 'Mariam Diallo', 
    phone: '+225 05 33 44 55', 
    email: 'mariam.d@example.com',
    status: 'active',
    registrationDate: '20/05/2025',
    rides: 7,
    balance: 1800
  },
];

const ClientsManagement: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Filtrer les clients en fonction de la recherche et du filtre de statut
  const filteredClients = clientsData.filter(client => {
    const matchesSearch = 
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.phone.includes(searchQuery) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || client.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  // Fonction pour obtenir la couleur du badge en fonction du statut
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'inactive': return 'bg-gray-500';
      case 'blocked': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };
  
  // Fonction pour obtenir le libellé du statut en français
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Actif';
      case 'inactive': return 'Inactif';
      case 'blocked': return 'Bloqué';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Gestion des Clients</h1>
      
      <Card>
        <CardContent className="pt-6">
          {/* Barre d'outils et filtres */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Rechercher par nom, téléphone, email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="w-full md:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Statut: Tous" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  <SelectItem value="active">Actif</SelectItem>
                  <SelectItem value="inactive">Inactif</SelectItem>
                  <SelectItem value="blocked">Bloqué</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700">
              + Ajouter un client
            </Button>
          </div>
          
          {/* Tableau des clients */}
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Téléphone</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Date d'inscription</TableHead>
                  <TableHead>Nb Trajets</TableHead>
                  <TableHead>Solde (FCFA)</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell>{client.id}</TableCell>
                    <TableCell className="font-medium">{client.name}</TableCell>
                    <TableCell>{client.phone}</TableCell>
                    <TableCell>{client.email}</TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeColor(client.status)}>
                        {getStatusLabel(client.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>{client.registrationDate}</TableCell>
                    <TableCell>{client.rides}</TableCell>
                    <TableCell>{client.balance.toLocaleString()} FCFA</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="icon" title="Voir/Modifier">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Bloquer/Débloquer">
                          <Ban className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Supprimer">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {/* Pagination */}
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-gray-500">
              Affichage de {filteredClients.length} clients sur {clientsData.length}
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" disabled>
                Précédent
              </Button>
              <Button variant="outline" size="sm" className="bg-blue-50">
                1
              </Button>
              <Button variant="outline" size="sm">
                2
              </Button>
              <Button variant="outline" size="sm">
                Suivant
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientsManagement;
