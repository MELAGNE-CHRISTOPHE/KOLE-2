import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { 
  Search, 
  Filter, 
  Plus, 
  Edit, 
  Eye, 
  ToggleLeft, 
  ToggleRight,
  Trash2,
  Star,
  Phone,
  Mail,
  Car
} from 'lucide-react';

const DriversManagement: React.FC = () => {
  // Données fictives pour la démonstration
  const drivers = [
    {
      id: 'CH001',
      nom: 'Kouadio',
      prenom: 'Konan',
      telephone: '+225 07 12 34 56',
      email: 'konan.kouadio@email.com',
      statut: 'Actif',
      dateInscription: '15/11/2024',
      note: 4.8,
      vehicule: 'Yamaha XTZ - AB 1234 CI',
      nombreCourses: 156
    },
    {
      id: 'CH002',
      nom: 'Traoré',
      prenom: 'Aminata',
      telephone: '+225 05 98 76 54',
      email: 'aminata.traore@email.com',
      statut: 'En attente',
      dateInscription: '20/11/2024',
      note: 0,
      vehicule: 'Honda CB - CD 5678 CI',
      nombreCourses: 0
    },
    {
      id: 'CH003',
      nom: 'Diabaté',
      prenom: 'Sekou',
      telephone: '+225 01 23 45 67',
      email: 'sekou.diabate@email.com',
      statut: 'Actif',
      dateInscription: '10/11/2024',
      note: 4.6,
      vehicule: 'Suzuki GSX - EF 9012 CI',
      nombreCourses: 89
    },
    {
      id: 'CH004',
      nom: 'Bamba',
      prenom: 'Fatou',
      telephone: '+225 09 87 65 43',
      email: 'fatou.bamba@email.com',
      statut: 'Inactif',
      dateInscription: '05/11/2024',
      note: 4.2,
      vehicule: 'Kawasaki Ninja - GH 3456 CI',
      nombreCourses: 45
    },
    {
      id: 'CH005',
      nom: 'Ouattara',
      prenom: 'Ibrahim',
      telephone: '+225 06 54 32 10',
      email: 'ibrahim.ouattara@email.com',
      statut: 'Actif',
      dateInscription: '01/11/2024',
      note: 4.9,
      vehicule: 'TVS Apache - IJ 7890 CI',
      nombreCourses: 203
    }
  ];

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case 'Actif':
        return <span className="status-online">Actif</span>;
      case 'Inactif':
        return <span className="status-offline">Inactif</span>;
      case 'En attente':
        return <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-semibold">En attente</span>;
      default:
        return <span className="status-offline">{statut}</span>;
    }
  };

  const renderStars = (note: number) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= note ? 'text-kole-orange fill-current' : 'text-gray-300'
            }`}
          />
        ))}
        <span className="ml-1 text-sm text-kole-text-secondary">{note > 0 ? note.toFixed(1) : 'N/A'}</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-kole-brown-dark">Gestion des Chauffeurs</h1>
        <Button className="kole-btn-primary">
          <Plus className="h-4 w-4 mr-2" />
          Ajouter Chauffeur
        </Button>
      </div>

      {/* Barre d'outils et filtres */}
      <Card className="kole-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-kole-text-secondary" />
                <Input
                  placeholder="Rechercher par nom, téléphone, immatriculation..."
                  className="pl-10 kole-input"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select className="kole-input w-40">
                <option value="">Tous les statuts</option>
                <option value="actif">Actif</option>
                <option value="inactif">Inactif</option>
                <option value="attente">En attente</option>
                <option value="rejete">Rejeté</option>
              </select>
              <Button variant="outline" className="border-kole-border">
                <Filter className="h-4 w-4 mr-2" />
                Filtrer
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des chauffeurs */}
      <Card className="kole-card">
        <CardHeader>
          <CardTitle className="text-kole-brown-dark">Liste des Chauffeurs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-kole-border">
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">ID</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Chauffeur</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Contact</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Statut</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Note</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Véhicule</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Courses</th>
                  <th className="text-left py-3 px-4 font-semibold text-kole-text-dark">Actions</th>
                </tr>
              </thead>
              <tbody>
                {drivers.map((driver) => (
                  <tr key={driver.id} className="border-b border-kole-border hover:bg-kole-cream-light transition-colors">
                    <td className="py-4 px-4 text-kole-text-dark font-medium">{driver.id}</td>
                    <td className="py-4 px-4">
                      <div>
                        <div className="font-semibold text-kole-text-dark">{driver.prenom} {driver.nom}</div>
                        <div className="text-sm text-kole-text-secondary">Inscrit le {driver.dateInscription}</div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center text-sm text-kole-text-dark">
                          <Phone className="h-3 w-3 mr-1" />
                          {driver.telephone}
                        </div>
                        <div className="flex items-center text-sm text-kole-text-secondary">
                          <Mail className="h-3 w-3 mr-1" />
                          {driver.email}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      {getStatusBadge(driver.statut)}
                    </td>
                    <td className="py-4 px-4">
                      {renderStars(driver.note)}
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center text-sm text-kole-text-dark">
                        <Car className="h-4 w-4 mr-2 text-kole-ocre" />
                        <div>
                          <div className="font-medium">{driver.vehicule}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="font-semibold text-kole-text-dark">{driver.nombreCourses}</span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-kole-blue-primary text-kole-blue-primary hover:bg-kole-blue-primary hover:text-white"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-kole-ocre text-kole-ocre hover:bg-kole-ocre hover:text-white"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className={`${
                            driver.statut === 'Actif' 
                              ? 'border-kole-red text-kole-red hover:bg-kole-red hover:text-white' 
                              : 'border-kole-green text-kole-green hover:bg-kole-green hover:text-white'
                          }`}
                        >
                          {driver.statut === 'Actif' ? <ToggleLeft className="h-4 w-4" /> : <ToggleRight className="h-4 w-4" />}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="flex items-center justify-between mt-6">
            <div className="text-sm text-kole-text-secondary">
              Affichage de 1 à 5 sur 5 chauffeurs
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" disabled className="border-kole-border">
                Précédent
              </Button>
              <Button size="sm" className="kole-btn-primary">
                1
              </Button>
              <Button variant="outline" size="sm" disabled className="border-kole-border">
                Suivant
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriversManagement;

