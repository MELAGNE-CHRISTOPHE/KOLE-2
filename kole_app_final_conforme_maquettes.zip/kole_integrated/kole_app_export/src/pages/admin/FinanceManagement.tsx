import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../../components/ui/table';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Eye, Calendar, Check, X } from 'lucide-react';

// Données fictives pour les transactions
const transactionsData = [
  { 
    id: 'TR001', 
    date: '05/06/2025',
    time: '10:15',
    type: 'payment',
    amount: 2500,
    currency: 'FCFA',
    associatedUser: 'Aminata Touré (CL001)',
    status: 'success',
    reference: 'TR100'
  },
  { 
    id: 'TR002', 
    date: '05/06/2025',
    time: '09:30',
    type: 'commission',
    amount: 500,
    currency: 'FCFA',
    associatedUser: 'Konan Kouadio (CH001)',
    status: 'success',
    reference: 'TR100'
  },
  { 
    id: 'TR003', 
    date: '05/06/2025',
    time: '08:45',
    type: 'payment',
    amount: 1800,
    currency: 'FCFA',
    associatedUser: 'Ibrahim Koné (CL002)',
    status: 'success',
    reference: 'TR099'
  },
  { 
    id: 'TR004', 
    date: '05/06/2025',
    time: '08:45',
    type: 'commission',
    amount: 360,
    currency: 'FCFA',
    associatedUser: 'Amara Traoré (CH002)',
    status: 'success',
    reference: 'TR099'
  },
  { 
    id: 'TR005', 
    date: '04/06/2025',
    time: '19:20',
    type: 'payment',
    amount: 4500,
    currency: 'FCFA',
    associatedUser: 'Aminata Touré (CL001)',
    status: 'success',
    reference: 'TR097'
  },
  { 
    id: 'TR006', 
    date: '04/06/2025',
    time: '19:20',
    type: 'commission',
    amount: 900,
    currency: 'FCFA',
    associatedUser: 'Moussa Bamba (CH004)',
    status: 'success',
    reference: 'TR097'
  },
  { 
    id: 'TR007', 
    date: '04/06/2025',
    time: '15:10',
    type: 'wallet_topup',
    amount: 10000,
    currency: 'FCFA',
    associatedUser: 'Mariam Diallo (CL005)',
    status: 'success',
    reference: 'WT001'
  },
  { 
    id: 'TR008', 
    date: '04/06/2025',
    time: '14:25',
    type: 'withdrawal',
    amount: 15000,
    currency: 'FCFA',
    associatedUser: 'Konan Kouadio (CH001)',
    status: 'success',
    reference: 'WD001'
  },
  { 
    id: 'TR009', 
    date: '03/06/2025',
    time: '18:30',
    type: 'wallet_topup',
    amount: 5000,
    currency: 'FCFA',
    associatedUser: 'Yao Kouassi (CL004)',
    status: 'failed',
    reference: 'WT002'
  },
];

// Données fictives pour les demandes de retrait
const withdrawalRequestsData = [
  { 
    id: 'WR001', 
    date: '05/06/2025',
    time: '11:30',
    driver: 'Amara Traoré',
    driverId: 'CH002',
    amount: 12000,
    currency: 'FCFA',
    status: 'pending',
    paymentMethod: 'Mobile Money',
    accountInfo: '+225 05 98 76 54'
  },
  { 
    id: 'WR002', 
    date: '05/06/2025',
    time: '10:45',
    driver: 'Fatou Diallo',
    driverId: 'CH003',
    amount: 8500,
    currency: 'FCFA',
    status: 'pending',
    paymentMethod: 'Bank Transfer',
    accountInfo: 'SGCI 0123456789'
  },
  { 
    id: 'WR003', 
    date: '04/06/2025',
    time: '16:20',
    driver: 'Moussa Bamba',
    driverId: 'CH004',
    amount: 20000,
    currency: 'FCFA',
    status: 'completed',
    paymentMethod: 'Mobile Money',
    accountInfo: '+225 07 65 43 21'
  },
  { 
    id: 'WR004', 
    date: '03/06/2025',
    time: '14:15',
    driver: 'Konan Kouadio',
    driverId: 'CH001',
    amount: 15000,
    currency: 'FCFA',
    status: 'completed',
    paymentMethod: 'Mobile Money',
    accountInfo: '+225 07 12 34 56'
  },
  { 
    id: 'WR005', 
    date: '02/06/2025',
    time: '09:50',
    driver: 'Aya Koné',
    driverId: 'CH005',
    amount: 7500,
    currency: 'FCFA',
    status: 'rejected',
    paymentMethod: 'Mobile Money',
    accountInfo: '+225 05 11 22 33'
  },
];

const FinanceManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState('transactions');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState('all');
  
  // Filtrer les transactions
  const filteredTransactions = transactionsData.filter(transaction => {
    const matchesSearch = 
      transaction.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.associatedUser.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesType = typeFilter === 'all' || transaction.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    
    // Filtrage par date (simplifié pour la démo)
    let matchesDate = true;
    if (dateRange === 'today') {
      matchesDate = transaction.date === '05/06/2025';
    } else if (dateRange === 'yesterday') {
      matchesDate = transaction.date === '04/06/2025';
    }
    
    return matchesSearch && matchesType && matchesStatus && matchesDate;
  });
  
  // Filtrer les demandes de retrait
  const filteredWithdrawals = withdrawalRequestsData.filter(withdrawal => {
    const matchesSearch = 
      withdrawal.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      withdrawal.driver.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || withdrawal.status === statusFilter;
    
    // Filtrage par date (simplifié pour la démo)
    let matchesDate = true;
    if (dateRange === 'today') {
      matchesDate = withdrawal.date === '05/06/2025';
    } else if (dateRange === 'yesterday') {
      matchesDate = withdrawal.date === '04/06/2025';
    }
    
    return matchesSearch && matchesStatus && matchesDate;
  });
  
  // Fonction pour obtenir la couleur du badge en fonction du statut
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500';
      case 'pending': return 'bg-amber-500';
      case 'failed': return 'bg-red-500';
      case 'completed': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };
  
  // Fonction pour obtenir le libellé du statut en français
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'success': return 'Réussi';
      case 'pending': return 'En attente';
      case 'failed': return 'Échoué';
      case 'completed': return 'Complété';
      case 'rejected': return 'Rejeté';
      default: return status;
    }
  };
  
  // Fonction pour obtenir le libellé du type de transaction en français
  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'payment': return 'Paiement trajet';
      case 'commission': return 'Commission';
      case 'wallet_topup': return 'Recharge portefeuille';
      case 'withdrawal': return 'Retrait chauffeur';
      default: return type;
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Finance & Transactions</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="transactions">Historique des Transactions</TabsTrigger>
          <TabsTrigger value="withdrawals">Demandes de Retrait</TabsTrigger>
        </TabsList>
        
        <TabsContent value="transactions" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              {/* Barre d'outils et filtres */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher par ID, référence, utilisateur..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div className="w-full md:w-48">
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Période" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les dates</SelectItem>
                      <SelectItem value="today">Aujourd'hui</SelectItem>
                      <SelectItem value="yesterday">Hier</SelectItem>
                      <SelectItem value="week">7 derniers jours</SelectItem>
                      <SelectItem value="month">30 derniers jours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-48">
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Type: Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="payment">Paiement trajet</SelectItem>
                      <SelectItem value="commission">Commission</SelectItem>
                      <SelectItem value="wallet_topup">Recharge portefeuille</SelectItem>
                      <SelectItem value="withdrawal">Retrait chauffeur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-48">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Statut: Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="success">Réussi</SelectItem>
                      <SelectItem value="pending">En attente</SelectItem>
                      <SelectItem value="failed">Échoué</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Tableau des transactions */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Date/Heure</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Montant</TableHead>
                      <TableHead>Utilisateur</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead>Référence</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{transaction.id}</TableCell>
                        <TableCell>{transaction.date} {transaction.time}</TableCell>
                        <TableCell>{getTypeLabel(transaction.type)}</TableCell>
                        <TableCell>{transaction.amount.toLocaleString()} {transaction.currency}</TableCell>
                        <TableCell>{transaction.associatedUser}</TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeColor(transaction.status)}>
                            {getStatusLabel(transaction.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>{transaction.reference}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" title="Voir Détails">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  Affichage de {filteredTransactions.length} transactions sur {transactionsData.length}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Précédent
                  </Button>
                  <Button variant="outline" size="sm" className="bg-blue-50">
                    1
                  </Button>
                  <Button variant="outline" size="sm">
                    2
                  </Button>
                  <Button variant="outline" size="sm">
                    Suivant
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="withdrawals" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              {/* Barre d'outils et filtres */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher par ID, chauffeur..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div className="w-full md:w-48">
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Période" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les dates</SelectItem>
                      <SelectItem value="today">Aujourd'hui</SelectItem>
                      <SelectItem value="yesterday">Hier</SelectItem>
                      <SelectItem value="week">7 derniers jours</SelectItem>
                      <SelectItem value="month">30 derniers jours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-48">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Statut: Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="pending">En attente</SelectItem>
                      <SelectItem value="completed">Complété</SelectItem>
                      <SelectItem value="rejected">Rejeté</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Tableau des demandes de retrait */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Date/Heure</TableHead>
                      <TableHead>Chauffeur</TableHead>
                      <TableHead>Montant</TableHead>
                      <TableHead>Méthode</TableHead>
                      <TableHead>Compte</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredWithdrawals.map((withdrawal) => (
                      <TableRow key={withdrawal.id}>
                        <TableCell>{withdrawal.id}</TableCell>
                        <TableCell>{withdrawal.date} {withdrawal.time}</TableCell>
                        <TableCell>{withdrawal.driver}</TableCell>
                        <TableCell>{withdrawal.amount.toLocaleString()} {withdrawal.currency}</TableCell>
                        <TableCell>{withdrawal.paymentMethod}</TableCell>
                        <TableCell>{withdrawal.accountInfo}</TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeColor(withdrawal.status)}>
                            {getStatusLabel(withdrawal.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" title="Voir Détails">
                              <Eye className="h-4 w-4" />
                            </Button>
                            {withdrawal.status === 'pending' && (
                              <>
                                <Button variant="ghost" size="icon" title="Approuver" className="text-green-600">
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" title="Rejeter" className="text-red-600">
                                  <X className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  Affichage de {filteredWithdrawals.length} demandes sur {withdrawalRequestsData.length}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Précédent
                  </Button>
                  <Button variant="outline" size="sm" className="bg-blue-50">
                    1
                  </Button>
                  <Button variant="outline" size="sm">
                    Suivant
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinanceManagement;
