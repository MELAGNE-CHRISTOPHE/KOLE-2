import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../../components/ui/table';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Eye, Calendar } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

// Données fictives pour les trajets en cours
const activeRidesData = [
  { 
    id: 'TR001', 
    client: 'Aminata Touré',
    clientId: 'CL001',
    driver: 'Konan Kouadio',
    driverId: 'CH001',
    startTime: '10:15',
    status: 'to_client',
    startLocation: { lat: 5.341, lng: -4.017 },
    endLocation: { lat: 5.345, lng: -4.025 },
    currentLocation: { lat: 5.343, lng: -4.020 }
  },
  { 
    id: 'TR002', 
    client: 'Ibrahim Koné',
    clientId: 'CL002',
    driver: 'Amara Traoré',
    driverId: 'CH002',
    startTime: '10:05',
    status: 'in_progress',
    startLocation: { lat: 5.338, lng: -4.022 },
    endLocation: { lat: 5.332, lng: -4.015 },
    currentLocation: { lat: 5.335, lng: -4.018 }
  },
  { 
    id: 'TR003', 
    client: 'Yao Kouassi',
    clientId: 'CL004',
    driver: 'Moussa Bamba',
    driverId: 'CH004',
    startTime: '10:20',
    status: 'to_client',
    startLocation: { lat: 5.347, lng: -4.010 },
    endLocation: { lat: 5.352, lng: -4.018 },
    currentLocation: { lat: 5.349, lng: -4.012 }
  },
];

// Données fictives pour l'historique des trajets
const rideHistoryData = [
  { 
    id: 'TR100', 
    date: '05/06/2025',
    time: '09:30',
    client: 'Mariam Diallo',
    clientId: 'CL005',
    driver: 'Konan Kouadio',
    driverId: 'CH001',
    from: 'Plateau, Abidjan',
    to: 'Cocody, Abidjan',
    duration: '25 min',
    distance: '5.2 km',
    price: 2500,
    driverEarning: 2000,
    commission: 500,
    status: 'completed'
  },
  { 
    id: 'TR099', 
    date: '05/06/2025',
    time: '08:45',
    client: 'Ibrahim Koné',
    clientId: 'CL002',
    driver: 'Amara Traoré',
    driverId: 'CH002',
    from: 'Marcory, Abidjan',
    to: 'Zone 4, Abidjan',
    duration: '15 min',
    distance: '3.1 km',
    price: 1800,
    driverEarning: 1440,
    commission: 360,
    status: 'completed'
  },
  { 
    id: 'TR098', 
    date: '05/06/2025',
    time: '08:15',
    client: 'Sophie Mensah',
    clientId: 'CL003',
    driver: 'Fatou Diallo',
    driverId: 'CH003',
    from: 'Yopougon, Abidjan',
    to: 'Adjamé, Abidjan',
    duration: '35 min',
    distance: '8.7 km',
    price: 3500,
    driverEarning: 2800,
    commission: 700,
    status: 'cancelled_client'
  },
  { 
    id: 'TR097', 
    date: '04/06/2025',
    time: '19:20',
    client: 'Aminata Touré',
    clientId: 'CL001',
    driver: 'Moussa Bamba',
    driverId: 'CH004',
    from: 'Treichville, Abidjan',
    to: 'Port-Bouët, Abidjan',
    duration: '40 min',
    distance: '12.3 km',
    price: 4500,
    driverEarning: 3600,
    commission: 900,
    status: 'completed'
  },
  { 
    id: 'TR096', 
    date: '04/06/2025',
    time: '18:05',
    client: 'Yao Kouassi',
    clientId: 'CL004',
    driver: 'Konan Kouadio',
    driverId: 'CH001',
    from: 'Cocody, Abidjan',
    to: 'Plateau, Abidjan',
    duration: '30 min',
    distance: '6.8 km',
    price: 3000,
    driverEarning: 2400,
    commission: 600,
    status: 'cancelled_driver'
  },
];

const RidesTracking: React.FC = () => {
  const [activeTab, setActiveTab] = useState('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState('today');
  
  // Filtrer l'historique des trajets
  const filteredHistory = rideHistoryData.filter(ride => {
    const matchesSearch = 
      ride.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ride.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ride.driver.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || ride.status === statusFilter;
    
    // Filtrage par date (simplifié pour la démo)
    let matchesDate = true;
    if (dateRange === 'today') {
      matchesDate = ride.date === '05/06/2025';
    } else if (dateRange === 'yesterday') {
      matchesDate = ride.date === '04/06/2025';
    }
    
    return matchesSearch && matchesStatus && matchesDate;
  });
  
  // Fonction pour obtenir la couleur du badge en fonction du statut
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'cancelled_client': return 'bg-red-500';
      case 'cancelled_driver': return 'bg-amber-500';
      case 'to_client': return 'bg-blue-500';
      case 'in_progress': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };
  
  // Fonction pour obtenir le libellé du statut en français
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Terminé';
      case 'cancelled_client': return 'Annulé (client)';
      case 'cancelled_driver': return 'Annulé (chauffeur)';
      case 'to_client': return 'Vers client';
      case 'in_progress': return 'En cours';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Suivi des Trajets</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="active">Trajets en Cours</TabsTrigger>
          <TabsTrigger value="history">Historique des Trajets</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Carte temps réel */}
                <div className="lg:col-span-2">
                  <div className="h-[500px] rounded-lg overflow-hidden border border-gray-200">
                    <MapContainer 
                      center={[5.341, -4.017]} 
                      zoom={13} 
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      />
                      {activeRidesData.map((ride) => (
                        <Marker key={ride.id} position={[ride.currentLocation.lat, ride.currentLocation.lng]}>
                          <Popup>
                            <div>
                              <h3 className="font-bold">{ride.driver}</h3>
                              <p>Client: {ride.client}</p>
                              <p>Statut: {getStatusLabel(ride.status)}</p>
                              <p>Trajet ID: {ride.id}</p>
                            </div>
                          </Popup>
                        </Marker>
                      ))}
                    </MapContainer>
                  </div>
                </div>
                
                {/* Liste des trajets actifs */}
                <div>
                  <h3 className="text-lg font-medium mb-4">Trajets Actifs</h3>
                  <div className="space-y-4">
                    {activeRidesData.map((ride) => (
                      <Card key={ride.id}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-bold">{ride.id}</h4>
                            <Badge className={getStatusBadgeColor(ride.status)}>
                              {getStatusLabel(ride.status)}
                            </Badge>
                          </div>
                          <div className="space-y-1 text-sm">
                            <p><span className="font-medium">Client:</span> {ride.client}</p>
                            <p><span className="font-medium">Chauffeur:</span> {ride.driver}</p>
                            <p><span className="font-medium">Début:</span> {ride.startTime}</p>
                          </div>
                          <Button variant="outline" size="sm" className="w-full mt-3">
                            <Eye className="h-4 w-4 mr-2" /> Détails
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              {/* Barre d'outils et filtres */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher par ID, client, chauffeur..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div className="w-full md:w-48">
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Période" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Aujourd'hui</SelectItem>
                      <SelectItem value="yesterday">Hier</SelectItem>
                      <SelectItem value="week">7 derniers jours</SelectItem>
                      <SelectItem value="month">30 derniers jours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-48">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Statut: Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="completed">Terminé</SelectItem>
                      <SelectItem value="cancelled_client">Annulé (client)</SelectItem>
                      <SelectItem value="cancelled_driver">Annulé (chauffeur)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button variant="outline" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Sélectionner dates
                </Button>
              </div>
              
              {/* Tableau de l'historique */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Date/Heure</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Chauffeur</TableHead>
                      <TableHead>Départ</TableHead>
                      <TableHead>Arrivée</TableHead>
                      <TableHead>Prix (FCFA)</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredHistory.map((ride) => (
                      <TableRow key={ride.id}>
                        <TableCell>{ride.id}</TableCell>
                        <TableCell>{ride.date} {ride.time}</TableCell>
                        <TableCell>{ride.client}</TableCell>
                        <TableCell>{ride.driver}</TableCell>
                        <TableCell>{ride.from}</TableCell>
                        <TableCell>{ride.to}</TableCell>
                        <TableCell>{ride.price.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeColor(ride.status)}>
                            {getStatusLabel(ride.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" title="Voir Détails">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  Affichage de {filteredHistory.length} trajets sur {rideHistoryData.length}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Précédent
                  </Button>
                  <Button variant="outline" size="sm" className="bg-blue-50">
                    1
                  </Button>
                  <Button variant="outline" size="sm">
                    2
                  </Button>
                  <Button variant="outline" size="sm">
                    Suivant
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RidesTracking;
