import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../../components/ui/table';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { AlertCircle, CheckCircle, Loader2, RefreshCw } from 'lucide-react';
import { collection, getDocs, doc, updateDoc, query, where } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "../../components/ui/alert";
import { useAuth } from '../../context/AuthContext';

interface User {
  id: string;
  email: string | null;
  phoneNumber: string | null;
  displayName?: string;
  role?: 'client' | 'driver' | 'admin';
  createdAt: Date;
  updatedAt: Date;
}

const UserRolesManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newRole, setNewRole] = useState<'client' | 'driver' | 'admin'>('client');
  const [isUpdating, setIsUpdating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  // Fonction pour afficher une notification toast
  const showToast = (title: string, description: string, variant: 'default' | 'destructive' = 'default') => {
    // Implémentation simplifiée sans dépendance externe
    alert(`${title}: ${description}`);
  };

  // Récupérer tous les utilisateurs depuis Firestore
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const usersCollection = collection(db, 'users');
      const usersSnapshot = await getDocs(usersCollection);
      
      const usersData: User[] = usersSnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          email: data.email || null,
          phoneNumber: data.phoneNumber || null,
          displayName: data.displayName || 'Utilisateur',
          role: data.role || 'client',
          createdAt: data.createdAt?.toDate() || new Date(),
          updatedAt: data.updatedAt?.toDate() || new Date()
        };
      });
      
      // Trier les utilisateurs par rôle et date de création
      usersData.sort((a, b) => {
        // D'abord par rôle (admin, driver, client)
        const roleOrder = { admin: 1, driver: 2, client: 3 };
        const roleA = a.role || 'client';
        const roleB = b.role || 'client';
        
        if (roleOrder[roleA as keyof typeof roleOrder] !== roleOrder[roleB as keyof typeof roleOrder]) {
          return roleOrder[roleA as keyof typeof roleOrder] - roleOrder[roleB as keyof typeof roleOrder];
        }
        
        // Ensuite par date de création (plus récent en premier)
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
      
      setUsers(usersData);
      setFilteredUsers(usersData);
      setError(null);
    } catch (err) {
      console.error("Erreur lors de la récupération des utilisateurs:", err);
      setError("Impossible de charger les utilisateurs. Veuillez réessayer.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Charger les utilisateurs au chargement du composant
  useEffect(() => {
    fetchUsers();
  }, []);

  // Filtrer les utilisateurs en fonction de la recherche et du filtre de rôle
  useEffect(() => {
    const filtered = users.filter(user => {
      const matchesSearch = 
        (user.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) || false) ||
        (user.email?.toLowerCase().includes(searchQuery.toLowerCase()) || false) ||
        (user.phoneNumber?.includes(searchQuery) || false);
        
      const matchesRole = roleFilter === 'all' || user.role === roleFilter;
      
      return matchesSearch && matchesRole;
    });
    
    setFilteredUsers(filtered);
  }, [searchQuery, roleFilter, users]);

  // Fonction pour mettre à jour le rôle d'un utilisateur
  const updateUserRole = async () => {
    if (!selectedUser || !newRole) return;
    
    try {
      setIsUpdating(true);
      
      // Vérifier si l'utilisateur tente de modifier son propre rôle
      if (currentUser && selectedUser.id === currentUser.uid) {
        showToast("Action non autorisée", "Vous ne pouvez pas modifier votre propre rôle.", "destructive");
        setIsUpdating(false);
        setIsDialogOpen(false);
        return;
      }
      
      // Vérifier s'il s'agit du dernier administrateur
      if (selectedUser.role === 'admin' && newRole !== 'admin') {
        // Compter le nombre d'administrateurs
        const adminQuery = query(collection(db, 'users'), where('role', '==', 'admin'));
        const adminSnapshot = await getDocs(adminQuery);
        
        if (adminSnapshot.size <= 1) {
          showToast("Action non autorisée", "Impossible de modifier le rôle du dernier administrateur.", "destructive");
          setIsUpdating(false);
          setIsDialogOpen(false);
          return;
        }
      }
      
      const userRef = doc(db, 'users', selectedUser.id);
      await updateDoc(userRef, { 
        role: newRole,
        updatedAt: new Date()
      });
      
      // Mettre à jour l'état local
      setUsers(prevUsers => 
        prevUsers.map(user => 
          user.id === selectedUser.id 
            ? { ...user, role: newRole, updatedAt: new Date() } 
            : user
        )
      );
      
      showToast("Rôle mis à jour", `Le rôle de ${selectedUser.displayName || selectedUser.email || selectedUser.phoneNumber} a été changé en ${getRoleLabel(newRole)}.`);
      
      setIsDialogOpen(false);
    } catch (err) {
      console.error("Erreur lors de la mise à jour du rôle:", err);
      showToast("Erreur", "Impossible de mettre à jour le rôle. Veuillez réessayer.", "destructive");
    } finally {
      setIsUpdating(false);
    }
  };

  // Fonction pour obtenir la couleur du badge en fonction du rôle
  const getRoleBadgeColor = (role?: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-500';
      case 'driver': return 'bg-blue-500';
      case 'client': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };
  
  // Fonction pour obtenir le libellé du rôle en français
  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'admin': return 'Administrateur';
      case 'driver': return 'Chauffeur';
      case 'client': return 'Client';
      default: return 'Inconnu';
    }
  };

  // Ouvrir la boîte de dialogue pour changer le rôle
  const openChangeRoleDialog = (user: User) => {
    setSelectedUser(user);
    setNewRole(user.role || 'client');
    setIsDialogOpen(true);
  };

  // Fonction pour rafraîchir la liste des utilisateurs
  const refreshUsersList = () => {
    setRefreshing(true);
    fetchUsers();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestion des Rôles Utilisateurs</h1>
        <Button 
          variant="outline" 
          onClick={refreshUsersList}
          disabled={refreshing || loading}
        >
          {refreshing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4 mr-2" />
          )}
          Actualiser
        </Button>
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Erreur</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardContent className="pt-6">
          {/* Barre d'outils et filtres */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Rechercher par nom, email, téléphone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="w-full md:w-48">
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Rôle: Tous" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  <SelectItem value="client">Client</SelectItem>
                  <SelectItem value="driver">Chauffeur</SelectItem>
                  <SelectItem value="admin">Administrateur</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Tableau des utilisateurs */}
          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex justify-center items-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                <span className="ml-2">Chargement des utilisateurs...</span>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nom</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Téléphone</TableHead>
                    <TableHead>Rôle</TableHead>
                    <TableHead>Date de création</TableHead>
                    <TableHead>Dernière mise à jour</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-10">
                        Aucun utilisateur trouvé
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id} className={currentUser && user.id === currentUser.uid ? "bg-blue-50" : ""}>
                        <TableCell className="font-mono text-xs">{user.id.substring(0, 8)}...</TableCell>
                        <TableCell className="font-medium">
                          {user.displayName || 'Non défini'}
                          {currentUser && user.id === currentUser.uid && (
                            <span className="ml-2 text-xs text-blue-600">(Vous)</span>
                          )}
                        </TableCell>
                        <TableCell>{user.email || 'Non défini'}</TableCell>
                        <TableCell>{user.phoneNumber || 'Non défini'}</TableCell>
                        <TableCell>
                          <Badge className={getRoleBadgeColor(user.role)}>
                            {getRoleLabel(user.role)}
                          </Badge>
                        </TableCell>
                        <TableCell>{user.createdAt.toLocaleDateString()}</TableCell>
                        <TableCell>{user.updatedAt.toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openChangeRoleDialog(user)}
                            disabled={currentUser && user.id === currentUser.uid}
                            title={currentUser && user.id === currentUser.uid ? "Vous ne pouvez pas modifier votre propre rôle" : "Modifier le rôle"}
                          >
                            Modifier le rôle
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </div>
          
          {/* Pagination (à implémenter si nécessaire) */}
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-gray-500">
              Affichage de {filteredUsers.length} utilisateurs sur {users.length}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Boîte de dialogue pour changer le rôle */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifier le rôle utilisateur</DialogTitle>
            <DialogDescription>
              Changer le rôle de {selectedUser?.displayName || selectedUser?.email || selectedUser?.phoneNumber}.
              Cette action modifiera les permissions de l'utilisateur dans l'application.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <label className="block text-sm font-medium mb-2">
              Nouveau rôle
            </label>
            <Select value={newRole} onValueChange={(value: 'client' | 'driver' | 'admin') => setNewRole(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un rôle" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="client">Client</SelectItem>
                <SelectItem value="driver">Chauffeur</SelectItem>
                <SelectItem value="admin">Administrateur</SelectItem>
              </SelectContent>
            </Select>
            
            {selectedUser?.role === 'admin' && newRole !== 'admin' && (
              <Alert className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Attention</AlertTitle>
                <AlertDescription>
                  Vous êtes sur le point de retirer les droits d'administrateur à cet utilisateur.
                  Assurez-vous qu'il existe au moins un autre administrateur dans le système.
                </AlertDescription>
              </Alert>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)} disabled={isUpdating}>
              Annuler
            </Button>
            <Button onClick={updateUserRole} disabled={isUpdating}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Mise à jour...
                </>
              ) : (
                'Confirmer'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserRolesManagement;
