import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Navigation, 
  Search, 
  Home,
  Activity,
  CreditCard,
  User,
  Target,
  Clock,
  Users
} from 'lucide-react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

// Configuration de Mapbox avec nouveau token
mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_API_KEY || 'pk.eyJ1IjoibWFudXNhaSIsImEiOiJjbTRqcjBqZGkwMWNrMnFzZGNqZjNhZGZjIn0.Oy8VQZQNGlMOBJYfHhKJdw';

const ClientMainMapPage: React.FC = () => {
  const navigate = useNavigate();
  const [location, setLocation] = useState<{latitude: number, longitude: number} | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [nearbyDrivers, setNearbyDrivers] = useState(3);
  const [activeTab, setActiveTab] = useState('home');
  
  useEffect(() => {
    // Obtenir la position actuelle du client
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ latitude, longitude });
        },
        (error) => {
          console.error('Erreur de géolocalisation:', error);
          // Position par défaut (Abidjan)
          setLocation({ latitude: 5.3364, longitude: -4.0267 });
        }
      );
    } else {
      // Position par défaut si géolocalisation non supportée
      setLocation({ latitude: 5.3364, longitude: -4.0267 });
    }
  }, []);

  useEffect(() => {
    if (location && !mapLoaded) {
      initializeMap();
    }
  }, [location, mapLoaded]);

  const initializeMap = () => {
    if (!location) return;

    try {
      const map = new mapboxgl.Map({
        container: 'map-container',
        style: 'mapbox://styles/mapbox/light-v11',
        center: [location.longitude, location.latitude],
        zoom: 14,
        attributionControl: false
      });

      map.on('load', () => {
        setMapLoaded(true);
        
        // Ajouter le marqueur de l'utilisateur (bleu selon les maquettes)
        new mapboxgl.Marker({ color: '#0052FF' })
          .setLngLat([location.longitude, location.latitude])
          .addTo(map);

        // Ajouter des marqueurs de chauffeurs simulés (orange selon les maquettes)
        const driverLocations = [
          [location.longitude + 0.01, location.latitude + 0.01],
          [location.longitude - 0.01, location.latitude + 0.005],
          [location.longitude + 0.005, location.latitude - 0.01]
        ];

        driverLocations.forEach((coords, index) => {
          const el = document.createElement('div');
          el.className = 'driver-marker';
          el.style.backgroundImage = 'url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJMMTMuMDkgOC4yNkwyMCA5TDEzLjA5IDE1Ljc0TDEyIDIyTDEwLjkxIDE1Ljc0TDQgOUwxMC45MSA4LjI2TDEyIDJaIiBmaWxsPSIjRkY4QzAwIi8+Cjwvc3ZnPgo=)';
          el.style.width = '24px';
          el.style.height = '24px';
          el.style.backgroundSize = 'contain';
          el.style.cursor = 'pointer';

          new mapboxgl.Marker(el)
            .setLngLat(coords)
            .addTo(map);
        });
      });

      map.on('error', (e) => {
        console.error('Erreur Mapbox:', e);
      });

    } catch (error) {
      console.error('Erreur d\'initialisation de la carte:', error);
    }
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate('/client/booking', { state: { destination: searchQuery } });
    }
  };

  const handleBookRide = () => {
    navigate('/client/booking');
  };

  return (
    <div className="min-h-screen bg-kole-cream-light relative">
      {/* Carte principale selon les maquettes */}
      <div className="relative h-screen">
        <div 
          id="map-container" 
          className="w-full h-full"
          style={{ height: 'calc(100vh - 80px)' }}
        />
        
        {/* Barre de recherche proéminente selon les maquettes */}
        <div className="absolute top-4 left-4 right-4 z-10">
          <div className="kole-card p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-kole-text-secondary" />
              <input
                type="text"
                placeholder="Où allez-vous ?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-10 kole-input text-lg font-medium"
              />
            </div>
          </div>
        </div>

        {/* Bouton de recentrage selon les maquettes */}
        <button 
          className="absolute bottom-24 right-4 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center border border-kole-border"
          onClick={() => {
            if (location) {
              // Recentrer la carte sur la position actuelle
              const mapContainer = document.getElementById('map-container');
              if (mapContainer) {
                initializeMap();
              }
            }
          }}
        >
          <Target className="h-6 w-6 text-kole-blue-primary" />
        </button>

        {/* Compteur de chauffeurs à proximité */}
        <div className="absolute top-20 left-4 z-10">
          <div className="bg-white rounded-full px-4 py-2 shadow-lg border border-kole-border flex items-center space-x-2">
            <Users className="h-4 w-4 text-kole-orange" />
            <span className="text-sm font-semibold text-kole-text-dark">
              {nearbyDrivers} chauffeurs à proximité
            </span>
          </div>
        </div>

        {/* Bouton de réservation rapide */}
        <div className="absolute bottom-24 left-4 z-10">
          <button 
            onClick={handleBookRide}
            className="kole-btn-primary px-6 py-3 text-lg font-semibold shadow-lg"
          >
            <MapPin className="h-5 w-5 mr-2" />
            Réserver un trajet
          </button>
        </div>
      </div>

      {/* Navigation inférieure selon les maquettes */}
      <div className="kole-bottom-nav">
        <button 
          className={`kole-nav-item ${activeTab === 'home' ? 'active' : ''}`}
          onClick={() => setActiveTab('home')}
        >
          <Home className="h-6 w-6" />
          <span>Accueil</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'trips' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('trips');
            navigate('/client/trips');
          }}
        >
          <Activity className="h-6 w-6" />
          <span>Trajets</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'wallet' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('wallet');
            navigate('/client/wallet');
          }}
        >
          <CreditCard className="h-6 w-6" />
          <span>Portefeuille</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('profile');
            navigate('/client/profile');
          }}
        >
          <User className="h-6 w-6" />
          <span>Profil</span>
        </button>
      </div>
    </div>
  );
};

export default ClientMainMapPage;

