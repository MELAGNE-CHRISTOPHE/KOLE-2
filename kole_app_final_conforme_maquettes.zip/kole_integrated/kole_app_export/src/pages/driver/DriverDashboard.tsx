import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Power,
  MapPin,
  Clock,
  DollarSign,
  Route,
  Star,
  Home,
  Activity,
  CreditCard,
  User,
  TrendingUp,
  Calendar
} from 'lucide-react';

const DriverDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [isOnline, setIsOnline] = useState(false);
  const [activeTab, setActiveTab] = useState('home');

  // Données simulées selon les maquettes
  const driverStats = {
    balance: 45750,
    todayEarnings: 12500,
    todayTrips: 8,
    todayHours: 6.5,
    todayDistance: 45.2,
    rating: 4.8,
    totalTrips: 342
  };

  const toggleOnlineStatus = () => {
    setIsOnline(!isOnline);
  };

  return (
    <div className="min-h-screen bg-kole-cream-light">
      {/* En-tête bleu avec solde selon les maquettes */}
      <div className="bg-kole-blue-primary text-white p-6 rounded-b-3xl">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-2xl font-bold">Tableau de bord</h1>
            <p className="text-blue-100">Chauffeur Kôlê</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Solde disponible</p>
            <p className="text-3xl font-bold">{driverStats.balance.toLocaleString()} FCFA</p>
          </div>
        </div>

        {/* Bouton de statut selon les maquettes */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={toggleOnlineStatus}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all ${
                isOnline 
                  ? 'bg-kole-green-success text-white' 
                  : 'bg-white text-kole-blue-primary'
              }`}
            >
              <Power className="h-5 w-5" />
              <span>{isOnline ? 'En ligne' : 'Hors ligne'}</span>
            </button>
            <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-kole-green-success' : 'bg-gray-400'} animate-pulse`}></div>
          </div>
          
          <div className="flex items-center space-x-2 text-blue-100">
            <Star className="h-5 w-5 text-yellow-400 fill-current" />
            <span className="font-semibold">{driverStats.rating}</span>
            <span className="text-sm">({driverStats.totalTrips} courses)</span>
          </div>
        </div>
      </div>

      {/* Cartes de statistiques selon les maquettes */}
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          {/* Carte Courses d'aujourd'hui */}
          <div className="kole-stat-card bg-gradient-to-br from-blue-50 to-blue-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-kole-blue-primary rounded-full flex items-center justify-center">
                <Route className="h-6 w-6 text-white" />
              </div>
              <TrendingUp className="h-5 w-5 text-kole-blue-primary" />
            </div>
            <div className="kole-stat-value text-kole-blue-primary">{driverStats.todayTrips}</div>
            <div className="kole-stat-label">Courses aujourd'hui</div>
          </div>

          {/* Carte Revenus d'aujourd'hui */}
          <div className="kole-stat-card bg-gradient-to-br from-green-50 to-green-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-kole-green-success rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
              <TrendingUp className="h-5 w-5 text-kole-green-success" />
            </div>
            <div className="kole-stat-value text-kole-green-success">{driverStats.todayEarnings.toLocaleString()}</div>
            <div className="kole-stat-label">FCFA aujourd'hui</div>
          </div>

          {/* Carte Temps de conduite */}
          <div className="kole-stat-card bg-gradient-to-br from-orange-50 to-orange-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-kole-orange rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <Calendar className="h-5 w-5 text-kole-orange" />
            </div>
            <div className="kole-stat-value text-kole-orange">{driverStats.todayHours}h</div>
            <div className="kole-stat-label">Temps de conduite</div>
          </div>

          {/* Carte Distance parcourue */}
          <div className="kole-stat-card bg-gradient-to-br from-purple-50 to-purple-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                <MapPin className="h-6 w-6 text-white" />
              </div>
              <Route className="h-5 w-5 text-purple-600" />
            </div>
            <div className="kole-stat-value text-purple-600">{driverStats.todayDistance}</div>
            <div className="kole-stat-label">km parcourus</div>
          </div>
        </div>

        {/* Actions rapides selon les maquettes */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-kole-text-dark">Actions rapides</h3>
          
          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={() => navigate('/driver/map')}
              className="kole-card p-4 flex items-center justify-between hover:shadow-lg transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-kole-blue-primary rounded-full flex items-center justify-center">
                  <MapPin className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-kole-text-dark">Voir la carte</p>
                  <p className="text-sm text-kole-text-secondary">Rechercher des clients</p>
                </div>
              </div>
              <div className="text-kole-blue-primary">→</div>
            </button>

            <button 
              onClick={() => navigate('/driver/earnings')}
              className="kole-card p-4 flex items-center justify-between hover:shadow-lg transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-kole-green-success rounded-full flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-kole-text-dark">Mes revenus</p>
                  <p className="text-sm text-kole-text-secondary">Historique et retraits</p>
                </div>
              </div>
              <div className="text-kole-green-success">→</div>
            </button>

            <button 
              onClick={() => navigate('/driver/trips')}
              className="kole-card p-4 flex items-center justify-between hover:shadow-lg transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-kole-orange rounded-full flex items-center justify-center">
                  <Activity className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-kole-text-dark">Historique des courses</p>
                  <p className="text-sm text-kole-text-secondary">Voir toutes mes courses</p>
                </div>
              </div>
              <div className="text-kole-orange">→</div>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation inférieure selon les maquettes */}
      <div className="kole-bottom-nav">
        <button 
          className={`kole-nav-item ${activeTab === 'home' ? 'active' : ''}`}
          onClick={() => setActiveTab('home')}
        >
          <Home className="h-6 w-6" />
          <span>Accueil</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'map' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('map');
            navigate('/driver/map');
          }}
        >
          <MapPin className="h-6 w-6" />
          <span>Carte</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'earnings' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('earnings');
            navigate('/driver/earnings');
          }}
        >
          <DollarSign className="h-6 w-6" />
          <span>Revenus</span>
        </button>
        
        <button 
          className={`kole-nav-item ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('profile');
            navigate('/driver/profile');
          }}
        >
          <User className="h-6 w-6" />
          <span>Profil</span>
        </button>
      </div>
    </div>
  );
};

export default DriverDashboard;

