import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

export default defineConfig({
  base: "/", 
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    // Désactiver la minification pour réduire l'utilisation de la mémoire
    minify: false,
    // Activer le code splitting pour réduire la taille des chunks
    rollupOptions: {
      output: {
        // Configuration des chunks pour éviter les conflits de déclaration
        manualChunks: {
          vendor: ["react", "react-dom", "react-router-dom"],
          // Séparation explicite des dépendances Firebase pour éviter les conflits
          firebase: [
            "firebase/app", 
            "firebase/auth", 
            "firebase/firestore"
          ],
          // Séparation des composants UI pour optimiser le chargement
          ui: [
            "@radix-ui/react-dialog",
            "@radix-ui/react-dropdown-menu",
            "@radix-ui/react-toast"
          ]
        }
      }
    },
    // Augmenter la limite d'avertissement pour les chunks
    chunkSizeWarningLimit: 1500,
    // Activer la génération de sourcemaps pour le débogage
    sourcemap: true,
    // Optimiser la taille des assets
    assetsInlineLimit: 4096,
    // Améliorer la gestion des erreurs pendant le build
    reportCompressedSize: true,
    // Optimiser les performances de build
    target: 'es2015',
    // Améliorer la compatibilité navigateur
    cssCodeSplit: true
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: false,
    // Activer CORS pour faciliter le développement
    cors: true,
    // Améliorer la gestion des erreurs
    hmr: {
      overlay: true
    },
    allowedHosts: [
      "5173-ip2ebehqgkzkci9zuahv2-5203bc7b.manusvm.computer",
      "5173-irjr4lzkfsx4ruojk38xd-5203bc7b.manusvm.computer",
      "irjr4lzkfsx4ruojk38xd-5203bc7b.manusvm.computer",
      "5174-icpm9gxbsthofydbdggtm-5203bc7b.manusvm.computer",
      "icpm9gxbsthofydbdggtm-5203bc7b.manusvm.computer",
      "5175-icpm9gxbsthofydbdggtm-5203bc7b.manusvm.computer",
      "5176-icpm9gxbsthofydbdggtm-5203bc7b.manusvm.computer",
      "5173-ipnqpn83vwt3mdj212xg9-1cfeead4.manusvm.computer",
      "5174-ipnqpn83vwt3mdj212xg9-1cfeead4.manusvm.computer",
      "5173-i0v3d1igytwb0r8pdmm90-38efec1f.manusvm.computer",
      // Ajouter localhost et tous les domaines manus.space pour faciliter le déploiement
      "localhost",
      "*.manus.space"
    ],
  },
  preview: {
    host: "0.0.0.0",
    port: 4173,
    // Activer CORS pour le mode preview
    cors: true
  },
  // Optimisation pour les environnements de développement et de production
  optimizeDeps: {
    // Inclure les dépendances qui peuvent causer des problèmes de chargement
    include: ['firebase/app', 'firebase/auth', 'firebase/firestore'],
    // Exclure les dépendances qui causent des conflits
    exclude: []
  }
})
